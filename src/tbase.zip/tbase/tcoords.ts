const dbug = (elem) => false //elem && elem.id === "jxgBoard1L9";
const dbugColor = `color:black;background-color:white`;

// TODO: need a way to mark Coord as invalid.   Geometry often sends [0, NaN, NaN] or Coords

import { TElement, Tinterface, TPosition } from "./tinterface.js"


import { JSXMath } from "../math/math.js";
import { COORDS_BY, OBJECT_TYPE, OBJECT_CLASS } from "../base/constants.js";
import { GeometryElement } from "../base/element.js";
import { Board } from "../base/board.js"


export class TCoords {

    public usrCoords: number[]
    public scrCoords: number[]
    public method: COORDS_BY
    public board: Board

    public _t: number = 0    // this is used in Plot.  need to document

    public length = 0       // used in Point3D, text3D, statistics, cinderella

    constructor(method: COORDS_BY, coordinates: number[], board: Board) {

        this.board = board

        console.assert(coordinates.length == 2 || coordinates.length == 3)

        // if (dbug(this.elem))
        console.warn(`%c coords [${JSON.stringify(coordinates)} ${method == COORDS_BY.USER ? 'User' : 'Screen'}]`, dbugColor)

        let oc = this.board.origin.scrCoords;

        if (method === COORDS_BY.USER) {
            this.usrCoords = (coordinates.length == 2) ? [coordinates[0], coordinates[1], 0] : coordinates
            this.scrCoords = this.usr2screen(this.usrCoords)
        } else {
            this.scrCoords = (coordinates.length == 2) ? [coordinates[0], coordinates[1], 0] : coordinates
            this.usrCoords = this.screen2usr(this.scrCoords)
        }


        // if (dbug(this.elem))
        console.warn(`%c new Coords scrCoords:${JSON.stringify(this.scrCoords)}}  usrCoords:${JSON.stringify(this.usrCoords)}}`, dbugColor)
    };

    /**
     * Normalize homogeneous coordinates
     * @private
     */
    normalizeUsrCoords() {
        if (Math.abs(this.usrCoords[0]) > JSXMath.eps) {
            this.usrCoords[1] /= this.usrCoords[0];
            this.usrCoords[2] /= this.usrCoords[0];
            this.usrCoords[0] = 1.0;
        }
    }

    /**
     * Compute screen coordinates out of given user coordinates.
     */
    private usr2screen(uc: number[]): number[] {
        let oc = this.board.origin.scrCoords;

        let scrCoords = []     // ALWAYS round to two decimal places
        scrCoords[0] = Math.round((oc[0] + (uc[0] * this.board.unitX)) * 100) / 100
        scrCoords[1] = Math.round((oc[1] + (uc[1] * this.board.unitY)) * 100) / 100
        scrCoords[2] = 0
        return scrCoords
    }

    /**
     * Compute user coordinates out of given screen coordinates.
     * uc is user coordinates, oc is board origin coordinates
     */
    private screen2usr(sc: number[]): number[] {
        let oc = this.board.origin.scrCoords;

        let usrCoords = []
        usrCoords[0] = (sc[0] - oc[0]) / this.board.unitX;
        usrCoords[1] = (oc[1] - sc[1]) / this.board.unitY;
        usrCoords[2] = 0;

        return usrCoords
    }

    /**
     * Calculate distance of one point to another.
     * @param {Number} coord_type The type of coordinates used here. Possible values are <b>COORDS_BY.USER</b> and <b>COORDS_BY.SCREEN</b>.
     * @param {JXG2.Coords} coordinates The Coords object to which the distance is calculated.
     * @returns {Number} The distance
     */
    distance(coord_type: COORDS_BY, coordinates: TCoords): number {
        var sum = 0,
            c,
            ucr = this.usrCoords,
            scr = this.scrCoords,
            f;

        if (coord_type === COORDS_BY.USER) {
            c = coordinates.usrCoords;
            f = ucr[0] - c[0];
            sum = f * f;

            if (sum > JSXMath.eps * JSXMath.eps) {
                return Number.POSITIVE_INFINITY;
            }
            return Math.hypot(ucr[1] - c[1], ucr[2] - c[2]);
        } else {
            c = coordinates.scrCoords;
            return Math.hypot(scr[1] - c[1], scr[2] - c[2]);
        }
    }

    /**
     * Set coordinates by either user coordinates or screen coordinates and recalculate the other one.
     * @param {Number} coord_type The type of coordinates used here. Possible values are <b>COORDS_BY_USER</b> and <b>COORDS_BY_SCREEN</b>.
     * @param {Array} coordinates An array of affine coordinates the Coords object is set to.
     * @param {Boolean} [doRound=true] flag If true or null round the coordinates in usr2screen. This is used in smooth curve plotting.
     * The IE needs rounded coordinates. Id doRound==false we have to round in updatePathString.
     * @param {Boolean} [noevent=false]
     * @returns {JXG2.Coords} Reference to the coords object.
     */
    setCoordinates(coord_type: COORDS_BY, coordinates: number[], doRound: boolean = true, noevent: boolean = false) {
        // console.log(`setCoordinates(${JSON.stringify(coordinates)})`)


        let uc = this.usrCoords,
            sc = this.scrCoords,
            // Original values
            ou = [uc[0], uc[1], uc[2]],
            os = [sc[0], sc[1], sc[2]];

        if (coord_type === COORDS_BY.USER) {
            if (coordinates.length === 2) {
                uc[0] = coordinates[0];
                uc[1] = coordinates[1];
                uc[2] = 0;
            }
        } else {
            if (coordinates.length === 2) {
                // Euclidean coordinates
                sc[0] = coordinates[0];
                sc[1] = coordinates[1];
                sc[2] = 0
                this.usrCoords = this.screen2usr(sc);
            }

            // if (dbug(this.elem))
            console.warn(`%c setCoordinates scrCoords:${JSON.stringify(this.scrCoords)}}`, dbugColor)

            return this;
        }
    }



    /**
     * Copy array, either scrCoords or usrCoords
     * Uses slice() in case of standard arrays and set() in case of
     * typed arrays.
     * @private
     * @param {String} obj Either 'scrCoords' or 'usrCoords'
     * @param {Number} offset Offset, defaults to 0 if not given
     * @returns {Array} Returns copy of the coords array either as standard array or as
     *   typed array.
     */
    copy(obj: string, offset = 0) {
        return this[obj].slice(offset);
    }

    /**
     * Test if one of the usrCoords is NaN or the coordinates are infinite.
     * @returns {Boolean} true if the coordinates are finite, false otherwise.
     */
    computeIsReal() {
        return (
            !isNaN(this.usrCoords[1] + this.usrCoords[2]) &&
            Math.abs(this.usrCoords[0]) > JSXMath.eps
        );
    }


}