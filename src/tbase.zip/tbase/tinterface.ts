import { OBJECT_TYPE } from "../base/constants"
import { Board } from "../base/board.js";
import { GeometryElement } from "../base/element";
import { LooseObject } from "../interfaces";
import { Type } from "../utils/type.js"


export type TPosition = [number | Function, number | Function, number | Function]


export abstract class TElement {
    elType: OBJECT_TYPE
    board: Board
    id: string

    visProp: LooseObject
    visPropOld: LooseObject
    visPropCalc: LooseObject = {visible:true}

    static numObjects = 0 // a unique number for each element

    constructor(elType: OBJECT_TYPE, board: Board) {

    }



    /**
     * Composes an id for an element. If the ID is empty ('' or null) a new ID is generated, depending on the
     * object type. As a side effect {@link JXG2.Board#numObjects}
     * is updated.
     * @param  obj Reference of an geometry object that needs an id.
     * @param type Type of the object.
     * @returns Unique id for an element.
     */
    setId(obj: TElement, type: string): string {
        console.assert(typeof obj == 'object', typeof obj)

        TElement.numObjects += 1;

        let newID = type + TElement.numObjects.toString().padStart(4,'0')
        return newID
    }

    /**
     * Get value of an attribute. If the value that attribute is a function, call the function and return its value.
     * In that case, the function is called with the GeometryElement as (only) parameter. For label elements (i.e.
     * if the attribute "islabel" is true), the anchor element is supplied. The label element can be accessed as
     * sub-object "label".
     * If the attribute does not exist, undefined will be returned.
     *
     * @param {String} key Attribute key
     * @returns {String|Number|Boolean} value of attribute "key" (evaluated in case of a function) or undefined
     *
     * @see GeometryElement#eval
     * @see JXG2#evaluate
     */
    evalVisProp(key) {

        var val, arr,
            e, o, found;

        key = key.toLowerCase();
        if (key.indexOf('.') === -1) {
            // e.g. 'visible'
            val = this.visProp[key];
        } else {
            // e.g. label.visible
            arr = key.split('.');
            if (arr.length == 2 && Type.exists(this.visProp[arr[0]])) {
                val = this.visProp[arr[0]][arr[1]]
            } else if (arr.length == 3 && Type.exists(this.visProp[arr[0]]) && Type.exists(this.visProp[arr[0]][arr[1]])) {
                val = this.visProp[arr[0]][arr[1]][arr[2]]
            } else {
                console.log(this)
                throw new Error(key)
            }

            // val = this.visProp;
            // for (i = 0; i < le; i++) {
            //     if (Type.exists(val)) {
            //         val = val[arr[i]];
            //     }
            // }
        }
        console.log(`evalVisProp(${key}) => ${val}`)
        return val

    }
}

export interface Tinterface {
    elType: OBJECT_TYPE
    update: Function
}

