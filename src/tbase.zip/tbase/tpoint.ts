import { watchElement } from "../jsxgraph.js"
const dbug = (elem) => elem.id == watchElement //elem && elem.id === "jxgBoard1L3";
const dbugColor = `color:red;background-color:lightblue`;

import { TElement, Tinterface, TPosition } from "./tinterface.js"

import { LooseObject } from "../interfaces.js";
import { Board } from "../base/board.js";
import { OBJECT_CLASS, OBJECT_TYPE, COORDS_BY } from "../base/constants.js";
import { TCoords } from "./tcoords.js";
import { Type } from "../utils/type.js"
import { Options } from "../options.js";




export class TPoint extends TElement implements Tinterface {

    parents: TPosition
    coords: TCoords

    // garbage below
    rendNode
    _is_new



    constructor(board: Board, parents: any[] /*TPosition*/, attributes: LooseObject) {
        super(OBJECT_TYPE.POINT, board)

        this.board = board          // TODO: Register point on board.

        this.coords = new TCoords(COORDS_BY.USER, parents, board)
        this.elType = OBJECT_TYPE.POINT
        this.id = this.setId(this, 'P');

        // if (dbug(this))
        console.warn(`%c create TPoint ${this.id}`, dbugColor, parents)

        this.visProp = Type.initVisProps(Options.elements, Options.point, attributes)
        this.visProp.visible = true;

        Type.clearVisPropOld(this)


        this.board.renderer.drawPoint(this);

    }

    // getters and setters

    get X() { return this.coords[0] }
    get Y() { return this.coords[1] }
    get Z() { return this.coords[2] }


    Coords(withZ = false) { return [this.coords[0], this.coords[1]] }

    update() {
    }

    /**  set new position, returning whether it was different from old position */
    setPosition(newPosition: TPosition): boolean {
        let oldPosition = this.coords.usrCoords
        return true
    }

    tPos2
}